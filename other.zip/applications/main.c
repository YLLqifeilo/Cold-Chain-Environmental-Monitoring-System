#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include <drv_common.h>
#include <string.h>
#include "aht10.h"
#include "ccs811.h"
#include "RC522.h"
#include <drv_lcd.h>
#include <rttlogo.h>

/* 调试宏定义 */
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG

/* 硬件引脚定义 */
#define ROW1_PIN       GET_PIN(D, 12)
#define ROW2_PIN       GET_PIN(B, 11)
#define ROW3_PIN       GET_PIN(B, 10)
#define ROW4_PIN       GET_PIN(D, 11)
#define COL1_PIN       GET_PIN(F, 4)
#define COL2_PIN       GET_PIN(F, 5)
#define COL3_PIN       GET_PIN(F, 6)
#define COL4_PIN       GET_PIN(F, 7)
#define DOOR_LOCK_PIN  GET_PIN(G, 1)
#define BEEP_PIN       GET_PIN(B, 0)
#define RC522_IRQ_PIN  GET_PIN(E, 3)

/* 传感器相关定义 */
#define CCS811_I2C_BUS_NAME   "i2c1"
#define AHT10_I2C_BUS_NAME    "i2c3"
#define TEMP_Y_POS            10
#define HUMI_Y_POS            (TEMP_Y_POS + 36)
#define TVOC_Y_POS            (HUMI_Y_POS + 36)
#define ECO2_Y_POS            (TVOC_Y_POS + 36)

/* 系统页面枚举 */
typedef enum {
    PAGE_PASSWORD_INPUT,
    PAGE_SENSOR_DATA,
    PAGE_INVENTORY_MANAGE
} system_page_t;

/* 库存操作模式 */
typedef enum {
    MODE_NONE,
    MODE_STOCK_IN,
    MODE_STOCK_OUT,
    MODE_STOCK_QUERY
} stock_mode_t;

/* 卡片信息结构 */
typedef struct {
    unsigned char uid[4];
    const char *name;
    int quantity;
} card_info_t;

/* 全局变量 */
static const int PASSWORD[] = {2, 6, 10, 14}; // 密码2580对应的键值
static int input_password[4] = {0};
static int password_index = 0;
static rt_bool_t password_verified = RT_FALSE;
static system_page_t current_page = PAGE_PASSWORD_INPUT;
static stock_mode_t current_mode = MODE_NONE;
static rt_thread_t rc522_thread = RT_NULL;
static rt_thread_t sensor_thread = RT_NULL;
static float humidity, temperature;
static aht10_device_t aht10_dev;

/* 已知卡片信息 */
static card_info_t known_cards[] = {
    {{0x4c, 0xbf, 0x4d, 0x5}, "apple", 0},
    {{0xb1, 0xbe, 0xca, 0x5}, "banana", 0},
};

/* 函数声明 */

/**
 * @brief 硬件初始化函数
 * @details 初始化系统中使用的所有硬件设备，包括传感器、LCD、GPIO等
 */
static void hardware_init(void);

/**
 * @brief 键盘初始化函数
 * @details 初始化4x4矩阵键盘的行列引脚，设置输入输出模式
 */
static void keypad_init(void);

/**
 * @brief 键盘扫描函数
 * @return 返回按下的键值(1-16)，无按键按下返回0
 * @details 通过行列扫描方式检测矩阵键盘的按键状态
 */
static uint8_t keypad_scan(void);

/**
 * @brief 显示密码输入页面
 * @details 清屏并显示密码输入界面，包含提示信息和输入框
 */
static void show_password_page(void);

/**
 * @brief 显示传感器数据页面
 * @details 清屏并显示传感器数据界面，启动传感器数据采集线程
 */
static void show_sensor_page(void);

/**
 * @brief 显示库存管理页面
 * @details 清屏并显示库存管理菜单界面，启动RFID读取线程
 */
static void show_inventory_page(void);

/**
 * @brief 页面切换函数
 * @param new_page 要切换到的目标页面
 * @details 清理当前页面资源，初始化并显示新页面
 */
static void switch_page(system_page_t new_page);

/**
 * @brief 处理密码输入
 * @param key 用户输入的键值
 * @details 记录用户输入的密码，显示输入进度，处理特殊功能键
 */
static void handle_password_input(uint8_t key);

/**
 * @brief 验证密码
 * @details 比较输入的密码与预设密码，验证通过后解锁门锁
 */
static void verify_password(void);

/**
 * @brief 重置密码输入
 * @details 清除已输入的密码，重置输入状态，刷新显示
 */
static void reset_password_input(void);

/**
 * @brief 处理库存管理输入
 * @param key 用户输入的键值
 * @details 根据按键选择库存操作模式(A:入库/B:出库/C:查询/D:退出)
 */
static void handle_inventory_input(uint8_t key);

/**
 * @brief 传感器数据采集线程入口
 * @param parameter 线程参数(未使用)
 * @details 周期性读取温湿度、TVOC和eCO2传感器数据并更新显示
 */
static void sensor_thread_entry(void *parameter);

/**
 * @brief RFID读取线程入口
 * @param parameter 线程参数(未使用)
 * @details 初始化RC522模块，循环检测RFID卡片并进行处理
 */
static void rc522_thread_entry(void *parameter);

/**
 * @brief RC522中断处理函数
 * @param args 中断参数(未使用)
 * @details 标记有卡片靠近的中断回调函数
 */
static void rc522_irq_handler(void *args);

/**
 * @brief 处理RFID卡片
 * @param uid 卡片UID(4字节数组)
 * @details 根据当前模式处理识别的卡片，更新库存信息并显示操作结果
 */
static void process_rfid_card(unsigned char *uid);

/* 主函数 */
int main(void)
{
    // 初始化硬件
    hardware_init();
    keypad_init();

    // 显示初始页面
    show_password_page();

    uint8_t last_key = 0;
    while (1) {
        uint8_t key = keypad_scan();

        if (key != 0 && key != last_key) {
            last_key = key;

            switch(current_page) {
                case PAGE_PASSWORD_INPUT:
                    handle_password_input(key);
                    break;

                case PAGE_SENSOR_DATA:
                    if (key == 15) { // 15键退出传感器页面
                        switch_page(PAGE_PASSWORD_INPUT);
                    }
                    break;

                case PAGE_INVENTORY_MANAGE:
                    handle_inventory_input(key);
                    break;
            }
        }
        else if (key == 0) {
            last_key = 0;
        }

        rt_thread_mdelay(20);
    }

    return 0;
}

/* 硬件初始化 */
static void hardware_init(void)
{
    /* 初始化AHT10 */
    aht10_dev = aht10_init(AHT10_I2C_BUS_NAME);
    if (aht10_dev == RT_NULL) {
        rt_kprintf("AHT10 sensor initialize failure");
    }
    rt_thread_mdelay(2000); // 等待传感器初始化
}

/* 键盘初始化 */
static void keypad_init(void)
{
    // 行引脚设置为输出模式
    rt_pin_mode(ROW1_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(ROW2_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(ROW3_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(ROW4_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(ROW1_PIN, PIN_HIGH);
    rt_pin_write(ROW2_PIN, PIN_HIGH);
    rt_pin_write(ROW3_PIN, PIN_HIGH);
    rt_pin_write(ROW4_PIN, PIN_HIGH);

    // 列引脚设置为输入上拉模式
    rt_pin_mode(COL1_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(COL2_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(COL3_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(COL4_PIN, PIN_MODE_INPUT_PULLUP);

    // 初始化控制引脚
    rt_pin_mode(DOOR_LOCK_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(BEEP_PIN, PIN_MODE_OUTPUT);
    rt_pin_write(DOOR_LOCK_PIN, PIN_LOW);
    rt_pin_write(BEEP_PIN, PIN_LOW);

    // 初始化RC522中断引脚
    rt_pin_mode(RC522_IRQ_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_attach_irq(RC522_IRQ_PIN, PIN_IRQ_MODE_FALLING, rc522_irq_handler, RT_NULL);
    rt_pin_irq_enable(RC522_IRQ_PIN, PIN_IRQ_ENABLE);
}

/* 键盘扫描 */
static uint8_t keypad_scan(void)
{
    uint8_t key = 0;

    // 扫描第1行
    rt_pin_write(ROW1_PIN, PIN_LOW);
    if (rt_pin_read(COL1_PIN) == PIN_LOW) key = 1;
    else if (rt_pin_read(COL2_PIN) == PIN_LOW) key = 2;
    else if (rt_pin_read(COL3_PIN) == PIN_LOW) key = 3;
    else if (rt_pin_read(COL4_PIN) == PIN_LOW) key = 4;
    rt_pin_write(ROW1_PIN, PIN_HIGH);
    if (key != 0) return key;

    // 扫描第2行
    rt_pin_write(ROW2_PIN, PIN_LOW);
    if (rt_pin_read(COL1_PIN) == PIN_LOW) key = 5;
    else if (rt_pin_read(COL2_PIN) == PIN_LOW) key = 6;
    else if (rt_pin_read(COL3_PIN) == PIN_LOW) key = 7;
    else if (rt_pin_read(COL4_PIN) == PIN_LOW) key = 8;
    rt_pin_write(ROW2_PIN, PIN_HIGH);
    if (key != 0) return key;

    // 扫描第3行
    rt_pin_write(ROW3_PIN, PIN_LOW);
    if (rt_pin_read(COL1_PIN) == PIN_LOW) key = 9;
    else if (rt_pin_read(COL2_PIN) == PIN_LOW) key = 10;
    else if (rt_pin_read(COL3_PIN) == PIN_LOW) key = 11;
    else if (rt_pin_read(COL4_PIN) == PIN_LOW) key = 12;
    rt_pin_write(ROW3_PIN, PIN_HIGH);
    if (key != 0) return key;

    // 扫描第4行
    rt_pin_write(ROW4_PIN, PIN_LOW);
    if (rt_pin_read(COL1_PIN) == PIN_LOW) key = 13;
    else if (rt_pin_read(COL2_PIN) == PIN_LOW) key = 14;
    else if (rt_pin_read(COL3_PIN) == PIN_LOW) key = 15;
    else if (rt_pin_read(COL4_PIN) == PIN_LOW) key = 16;
    rt_pin_write(ROW4_PIN, PIN_HIGH);

    return key;
}

/* 页面管理函数 */
static void show_password_page(void)
{
    lcd_clear(WHITE);
    lcd_show_image(0, 0, 240, 69, image_rttlogo);
    lcd_set_color(WHITE, BLACK);
    lcd_draw_line(0, 69 + 16 + 24 + 32, 240, 69 + 16 + 24 + 32);
    lcd_show_string(30, 80, 24, "Enter Password:");
    reset_password_input();
}

static void show_sensor_page(void)
{
    lcd_clear(WHITE);
    lcd_show_string(80, 10, 16, "SENSOR DATA");

    if (sensor_thread == RT_NULL) {
        sensor_thread = rt_thread_create("sensor_task",
                                      sensor_thread_entry,
                                      RT_NULL,
                                      2048,
                                      RT_THREAD_PRIORITY_MAX / 2,
                                      10);
        if (sensor_thread != RT_NULL) {
            rt_thread_startup(sensor_thread);
        }
    }
}

static void show_inventory_page(void)
{
    lcd_clear(WHITE);
    lcd_show_string(50, 10, 24, "INVENTORY MENU");
    lcd_show_string(20, 40, 24, "A: Stock IN");
    lcd_show_string(20, 70, 24, "B: Stock OUT");
    lcd_show_string(20, 100, 24, "C: Stock Query");
    lcd_show_string(20, 130, 24, "D: Exit");
    lcd_draw_line(0, 160, 240, 160);

    if (rc522_thread == RT_NULL) {
        rc522_thread = rt_thread_create("rc522_task",
                                     rc522_thread_entry,
                                     RT_NULL,
                                     1024,
                                     16,
                                     10);
        if (rc522_thread != RT_NULL) {
            rt_thread_startup(rc522_thread);
        }
    }
}

static void switch_page(system_page_t new_page)
{
    // 清理当前页面资源
    if (current_page == PAGE_SENSOR_DATA && sensor_thread != RT_NULL) {
        rt_thread_delete(sensor_thread);
        sensor_thread = RT_NULL;
    }
    else if (current_page == PAGE_INVENTORY_MANAGE && rc522_thread != RT_NULL) {
        rt_thread_delete(rc522_thread);
        rc522_thread = RT_NULL;
    }

    current_page = new_page;
    current_mode = MODE_NONE;

    // 初始化新页面
    switch(new_page) {
        case PAGE_PASSWORD_INPUT:
            show_password_page();
            break;
        case PAGE_SENSOR_DATA:
            show_sensor_page();
            break;
        case PAGE_INVENTORY_MANAGE:
            show_inventory_page();
            break;
    }
}

/* 密码处理函数 */
static void handle_password_input(uint8_t key)
{
    if (key == 13) { // 13键进入传感器页面
        switch_page(PAGE_SENSOR_DATA);
        return;
    }

    if (password_index < 4) {
        input_password[password_index] = key;
        password_index++;

        // 显示输入进度
        switch(password_index) {
            case 1: lcd_show_string(27, 120, 24, "*"); break;
            case 2: lcd_show_string(80, 120, 24, "*"); break;
            case 3: lcd_show_string(133, 120, 24, "*"); break;
            case 4: lcd_show_string(187, 120, 24, "*");
                    verify_password();
                    break;
        }
    }
}

static void verify_password(void)
{
    int correct = 1;
    for (int i = 0; i < 4; i++) {
        if (input_password[i] != PASSWORD[i]) {
            correct = 0;
            break;
        }
    }

    if (correct) {
        rt_pin_write(DOOR_LOCK_PIN, PIN_HIGH);
        rt_pin_write(BEEP_PIN, PIN_HIGH);
        lcd_show_string(50, 150, 16, "Welcome!");
        rt_thread_mdelay(2000);
        rt_pin_write(DOOR_LOCK_PIN, PIN_LOW);
        rt_pin_write(BEEP_PIN, PIN_LOW);
        password_verified = RT_TRUE;
        switch_page(PAGE_INVENTORY_MANAGE);
    } else {
        rt_pin_write(BEEP_PIN, PIN_HIGH);
        lcd_show_string(50, 150, 16, "Failed, try again");
        rt_thread_mdelay(500);
        rt_pin_write(BEEP_PIN, PIN_LOW);
        reset_password_input();
    }
}

static void reset_password_input(void)
{
    password_index = 0;
    for (int i = 0; i < 4; i++) {
        input_password[i] = 0;
    }
    password_verified = RT_FALSE;
    lcd_set_color(WHITE, BLACK);
    lcd_fill(0, 120, 240, 240, WHITE);
}

/* 库存管理处理函数 */
static void handle_inventory_input(uint8_t key)
{
    lcd_fill(0, 170, 240, 240, WHITE);

    switch(key) {
        case 4: // A键 - 入库
            current_mode = MODE_STOCK_IN;
            lcd_show_string(20, 170, 16, "IN Mode: Scan card");
            break;
        case 8: // B键 - 出库
            current_mode = MODE_STOCK_OUT;
            lcd_show_string(20, 170, 16, "OUT Mode: Scan card");
            break;
        case 12: // C键 - 查询
            current_mode = MODE_STOCK_QUERY;
            lcd_show_string(20, 170, 16, "QUERY Mode: Scan card");
            break;
        case 16: // D键 - 退出
            switch_page(PAGE_PASSWORD_INPUT);
            break;
    }
}

static void sensor_thread_entry(void *parameter)
{
    ccs811_device_t ccs811 = ccs811_create(CCS811_I2C_BUS_NAME);

    if (!ccs811) {
        rt_kprintf("CCS811 Init failed\n");
        return;
    }

    ccs811_set_measure_cycle(ccs811, CCS811_CYCLE_250MS);
    ccs811_set_baseline(ccs811, 0x847B);

    // 添加一个缓冲区用于旧TVOC值的显示长度
    static int prev_tvoc_len = 0;

    while (current_page == PAGE_SENSOR_DATA) {
        // 读取温湿度
        if (aht10_dev != RT_NULL) {
            humidity = aht10_read_humidity(aht10_dev);
            temperature = aht10_read_temperature(aht10_dev);

            lcd_show_string(45, TEMP_Y_POS, 24, "temp: %d.%d",
                          (int)temperature, (int)(temperature * 10) % 10);
            lcd_show_string(45, HUMI_Y_POS, 24, "humi: %d.%d %%",
                          (int)humidity, (int)(humidity * 10) % 10);

            lcd_show_string(180-15+9, TEMP_Y_POS-6-2, 16, "o");
            lcd_show_string(180-15+8+8, TEMP_Y_POS, 24, "C");
        }

        // 读取TVOC和eCO2
        if (ccs811_check_ready(ccs811)) {
            if (!ccs811_measure(ccs811)) {
                rt_kprintf("CCS811 Measurement failed\n");
                break;
            }

            // 计算当前TVOC值的字符串长度
            char tvoc_str[16];
            int current_len = rt_sprintf(tvoc_str, "TVOC: %d ppb", (int)ccs811->TVOC);

            // 如果新值比旧值短，先清除旧文本
            if (current_len < prev_tvoc_len) {
                lcd_fill(45, TVOC_Y_POS, 45 + prev_tvoc_len * 12, TVOC_Y_POS + 24, WHITE);
            }

            // 显示新值并更新长度记录
            lcd_show_string(45, TVOC_Y_POS, 24, tvoc_str);
            prev_tvoc_len = current_len;

            lcd_show_string(45, ECO2_Y_POS, 24, "eCO2: %d ppm", (int)ccs811->eCO2);
        }

        rt_thread_mdelay(1000);
    }

    if (ccs811) {
        ccs811_delete(ccs811);
    }
}

/* RC522相关函数 */
static void rc522_irq_handler(void *args)
{
    // 标记有卡片靠近
}

static void rc522_thread_entry(void *parameter)
{
    char status;
    unsigned char tag_type[2];
    unsigned char uid[4];

    PcdInit();
    PcdReset();
    PcdAntennaOff();
    PcdAntennaOn();
    M500PcdConfigISOType('A');
    rt_kprintf("RC522 initialized\n");

    while (current_page == PAGE_INVENTORY_MANAGE) {
        status = PcdRequest(REQ_ALL, tag_type);
        if (status == MI_OK) {
            status = PcdAnticoll(uid);
            if (status == MI_OK) {
                process_rfid_card(uid);
                WaitCardOff();
            }
        }
        rt_thread_mdelay(50);
    }
}

static void process_rfid_card(unsigned char *uid)
{
    int found = 0;
    // 保存上一次显示的字符串长度
    static int prev_info_len = 0;
    static int prev_action_len = 0;

    for (int i = 0; i < sizeof(known_cards)/sizeof(known_cards[0]); i++) {
        if (memcmp(uid, known_cards[i].uid, 4) == 0) {
            found = 1;
            char info[50];
            int current_info_len = rt_sprintf(info, "Card: %s Qty: %d", known_cards[i].name, known_cards[i].quantity);

            // 清除旧的信息显示区域
            lcd_fill(20, 190, 20 + prev_info_len * 8, 190 + 16, WHITE);
            lcd_show_string(20, 190, 16, info);
            prev_info_len = current_info_len;

            char action[30];
            int current_action_len = 0;

            switch(current_mode) {
                case MODE_STOCK_IN:
                    known_cards[i].quantity++;
                    current_action_len = rt_sprintf(action, "IN +1, New Qty: %d", known_cards[i].quantity);
                    break;
                case MODE_STOCK_OUT:
                    if (known_cards[i].quantity > 0) {
                        known_cards[i].quantity--;
                        current_action_len = rt_sprintf(action, "OUT -1, New Qty: %d", known_cards[i].quantity);
                    } else {
                        current_action_len = rt_sprintf(action, "OUT Failed: No stock");
                    }
                    break;
                case MODE_STOCK_QUERY:
                    current_action_len = rt_sprintf(action, "QUERY: %d", known_cards[i].quantity);
                    break;
                default:
                    break;
            }

            // 清除旧的操作结果显示区域
            lcd_fill(20, 210, 20 + prev_action_len * 8, 210 + 16, WHITE);
            lcd_show_string(20, 210, 16, action);
            prev_action_len = current_action_len;

            break;
        }
    }

    if (!found) {
        // 清除旧的未知卡片信息显示区域
        lcd_fill(20, 190, 20 + prev_info_len * 8, 190 + 16, WHITE);
        lcd_show_string(20, 190, 16, "Unknown card");
        prev_info_len = 12; // "Unknown card"长度为12
    }
}
